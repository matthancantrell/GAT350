#include "ResourceManager.h"

namespace neu
{
	void ResourceManager::Initialize()
	{
		//
	}

	void ResourceManager::Shutdown()
	{
		m_resources.clear();
	}


}
